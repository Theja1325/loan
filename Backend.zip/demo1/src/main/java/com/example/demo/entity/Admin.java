package com.example.demo.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "adminpage")
public class Admin {

    @Id
    @GeneratedValue
    private int id;
    private String name;
    private String dateofbirth;
    private int itemprice;
    private int payment;
    private int loanbalance;
    private String installmentplan;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDateofbirth() {
        return dateofbirth;
    }

    public void setDateofbirth(String dateofbirth) {
        this.dateofbirth = dateofbirth;
    }

    public int getItemprice() {
        return itemprice;
    }

    public void setItemprice(int itemprice) {
        this.itemprice = itemprice;
    }

    public int getPayment() {
        return payment;
    }

    public void setPayment(int payment) {
        this.payment = payment;
    }

    public int getLoanbalance() {
        return loanbalance;
    }

    public void setLoanbalance(int loanbalance) {
        this.loanbalance = loanbalance;
    }

    public String getInstallmentplan() {
        return installmentplan;
    }

    public void setInstallmentplan(String installmentplan) {
        this.installmentplan = installmentplan;
    }
}




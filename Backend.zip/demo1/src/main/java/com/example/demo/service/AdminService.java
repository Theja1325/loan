package com.example.demo.service;

import com.example.demo.entity.Admin;
import com.example.demo.repository.AdminRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AdminService {

    @Autowired
    private AdminRepository repository;

    public Admin saveAdmin(Admin admin) {
        return repository.save(admin);
    }

    public List<Admin> saveAdmins(List<Admin> admins) {
        return repository.saveAll(admins);
    }

    public List<Admin> getAdmins() {
        return repository.findAll();
    }

    public Admin getAdminById(int id) {
        return repository.findById(id).orElse(null);
    }

    public Admin getAdminByName(String name) {
        return repository.findByName(name);
    }

    public String deleteAdmin(int id) {
        repository.deleteById(id);
        return "user removed !! " + id;
    }

    public Admin updateAdmin(Admin admin) {
        Admin existingAdmin= repository.findById(admin.getId()).orElse(null);
        existingAdmin.setName(admin.getName());
        existingAdmin.setDateofbirth(admin.getDateofbirth());
        existingAdmin.setItemprice(admin.getItemprice());
        existingAdmin.setPayment(admin.getPayment());
        existingAdmin.setLoanbalance(admin.getLoanbalance());
        existingAdmin.setInstallmentplan(admin.getInstallmentplan());
        return repository.save(existingAdmin);
    }
}
